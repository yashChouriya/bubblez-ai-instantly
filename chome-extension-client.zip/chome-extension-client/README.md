# To use this extension follow the step:

1. Go to [chrome://extensions/](chrome://extensions/)
2. Enable developer mode from right upper corner.
3. Click on load unpack button left upper corner.
4. You need to select the "**chome-extension-client**" folder.
5. You'll see the extension loaded.
